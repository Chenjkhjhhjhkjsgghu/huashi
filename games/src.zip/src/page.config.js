import Vue from 'vue'
let data = {
    'hjba': 'http://api.fq98.com:82',
    'shijie':'http://api.fq98.com:83'
}

Vue.prototype.SITEINFO = data;

export default data;