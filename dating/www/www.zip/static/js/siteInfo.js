//站点对应的后台地址
const siteInfo = {
    'shijie':'http://api.fq98.com:84',
    'yueba':'http://api.fq98.com:84',
    'hjba': 'http://api.fq98.com:84'
}