
var siteInfo = {
        'shijie': {url:'http://rooms.fq98.com:83',name:'视界'},
        '2019yl': {url:'http://rooms.fq98.com:83',name:'2019yl'},
        'bycheng': {url:'http://rooms.fq98.com:83',name:'不夜城'},
        'hjba':{url:'http://rooms.fq98.com:83',name:'欢聚吧'}
}
$(document).ready(function () {
    function getRequest() {
        var url = window.location.search; //获取url中"?"符后的字串
        console.log(url)
        var theRequest = new Object();
        if (url.indexOf("?") != -1) {
            var str = url.substr(1);
            var strs = str.split("&");
            for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = decodeURI(strs[i].split("=")[1]);
            }
        }
        return theRequest;
    }
    var urlData = getRequest()
    var roomid = urlData.roomid
    var siteid = urlData.sites
    var sid = urlData.sid
    var data = {}
    $('.titleInfo').text(siteInfo[siteid].name+'--多人视频室主后台管理系统')
    $('.titleStr').text(siteInfo[siteid].name+'--多人视频室主后台管理系统')
    data.roomid = roomid
    data.siteid = siteid
    data.sid = sid
    $.ajax({
        type: "GET",
        url: siteInfo[getRequest().sites].url+'/shizhu/verifyUser',
        data: data,
        dataType: "json",
        success: function (res) {
            if (res && res.error_code == 'SUCCESS') {
                //    alert('登录成功')
                //face_id
                var src = '/header/' + res.result.lists.face_id + '.bmp'
                var img = '  <img class="nav-user-photo"src="' + src + '"  alt="Jason\'s Photo" />'
                $(".image").html(img);
                var html = '<small>Welcome</small>' + res.result.lists.id + '（房间：' + roomid + '）'
                $('.user-info').html(html)
                $('.pull').show()
            } else {
                if (res && res.reason) {
                    alert(res.reason)
                } else {
                    alert('请求失败')
                }
            }
        }
    })
})