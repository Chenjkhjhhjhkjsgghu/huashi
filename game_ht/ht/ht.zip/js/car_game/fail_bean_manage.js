  $(function () {
    var dataList = {
      page: 1,
      page_size: 10
      user_id:'',
      status:"",
      type:""
    }
    getRecord(dataList)
    $('#form_search').on('submit',function() {
      formSubmit()
      return false
    })
    $('#form_search2').on('submit',function() {
      formSubmit()
      return false
    })
  })
  // 按条件搜索
  function formSubmit() {
    var type = $('#search_type').val()
    var status = $('#search_status').val()
    var idx = $('#id_idx').val()
    var data = {
      page:1,
      page_size:20,
      user_id:idx,
      status:status,
      type:type
    }
    getRecord(data)
  }
  // 按条件搜索列表
  function getRecord(data) {
    dataList = data
    $.ajax({
      type: "POST",
      xhrFields:{
        withCredentials:true
        },
        url: _json_url.url+'/get_fail_bean_list',
      data: data,
      dataType: "json",
      success:function(res){
        res.pageNo=1;
        res.allPage = 1;
        res.allNum = 1;
        if(res.code===100)
          {
            top.window.location.href = '/?sites='+_sites
            return;
          }  
          if (res.error_code == 'SUCCESS') {

        
        recordList(res.lists)
        $(".pagination").paging({
          pageNo: res.pageNo,
          totalPage: res.allPage,
          totalSize: res.allNum,
          callback: function(num) {
            getPageList(num)
          }
        })
        $('.allNum').html(res.allNum)
        $('.allPage').html(res.allPage)
      }
    }
    // console.log(dataList)
  })}
  // 按分页搜索列表
  function getPageList(num) {
    dataList.page = num
    getRecord(dataList)
  }
  // 渲染列表
  function recordList(lists) {
    var dom = $('#mainTable tbody')
    dom.empty()
    for(var i = 0;i<lists;i++)
    {
       lists[i].status = lists[i].status!==0?'成功':'失败'
       lists[i].type = lists[i].type!==0?'加豆':'扣豆'
    }
    // console.log(list)
    var html = tmpl('table_list', list);

    dom.html(html)
  }
  function setTime(date) {
    date = new Date(date)
    return date.getTime()
  }
